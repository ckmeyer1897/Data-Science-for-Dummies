/// <reference types="react-scripts" />

declare module "iframe-resizer/js/iframeResizer"
declare module "!!raw-loader!*" {
    const content: string
    export default content
}
